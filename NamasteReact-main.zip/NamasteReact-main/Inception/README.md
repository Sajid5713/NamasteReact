Q: What is Emmet?
Ans: An Emmet is a toolkit that enables the developer to write large block of html code by using a simple shortcode. They can be achieved by using various tool or extension.

Q: Difference between a Library and Framework?
Ans: The main difference between Library and Framework is as follow:

● Library: A library provide functionality to alter specific portion of code. Like in react, we can only alter the portion and other html remain intact.

● Framework: Framework provides ready to use tools, or code to developed software application. Some of the examples of framework are Angular.js 

Q: What is CDN? Why do we use it?
Ans: CDN (content delivery Network) is a network of interconnected server's, that are user to provide better loading speed for masses of request. 

The CDN are used to provide faster loading response to client when requested for a asset or resource. Cdn work like signal tower system of our phone that a user connect to which is near in reach.

Q: Why is React known as React?
Ans: It was Library developed by facebook developer in 2013 and it was named "React" because it was meant to help developers to build fast and "reactive" interfaces.

Q: What is cross-origin in the script tag?
Ans: When we want to load a resources from another domain aside from our own domain. Here is where CROS is needed. It is way to interact between browser and server; it also determine if it is safe to allow cross-origin request. So it is basically used for the security purpose.

Q: What is the difference between React and ReactDOM?
Ans: The React is Library to build user interfaces using React functionality. We can create elements and things. While ReactDOM is Library that allow react to interact with DOM. It is glue between React and DOM. 

Q: What is difference between react.development.js and react.production.js files via CDN?
Ans: react.development.js library is used for development environment. It includes additional error features and warning that helps the developers to fix the code with ease.

react.production.js is used for production environment. It removed all the development-specific warnings and optimizations, resulting in a smaller and more efficient code bundle 


Q: What are async and defer?
Ans:  When a page is render in browser that are some mechanism taking place in the backend.

● Normal Execution: When a page load it will parse the HTML and when it encountered script it will pause the HTML parsing, loads the script and run the script on the page and then afterward the HTML is starts rendering.

● Async Execution: When a page load it will parse the HTML along with fetching the script from resource and when the script code is fully fetch will pause the HTML parsing and run the script. When the script is execute then run the HTML to Finish.

● Defer Execution: It run both the HTML and fetch/download scripts from resource and after the HTML parsing is done; then run the script at the end.
